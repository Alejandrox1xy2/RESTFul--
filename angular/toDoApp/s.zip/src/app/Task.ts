export class Task{
    _id?:string;
    title:string;
    isDone:boolean;
}

